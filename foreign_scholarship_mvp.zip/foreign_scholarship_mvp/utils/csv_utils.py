"""
CSV loading / saving helpers shared across the app.
All persistence is flat-file CSV for the MVP (see README for the
Postgres migration path).
"""
import os
import pandas as pd
import streamlit as st

DATA_DIR = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "data")


def _path(filename: str) -> str:
    return os.path.join(DATA_DIR, filename)


@st.cache_data(show_spinner=False)
def load_csv(filename: str) -> pd.DataFrame:
    path = _path(filename)
    if not os.path.exists(path):
        return pd.DataFrame()
    return pd.read_csv(path)


def save_csv(df: pd.DataFrame, filename: str) -> None:
    df.to_csv(_path(filename), index=False)
    # Invalidate cache so subsequent loads see the new data.
    load_csv.clear()


def append_row_csv(row: dict, filename: str) -> None:
    path = _path(filename)
    df_new = pd.DataFrame([row])
    if os.path.exists(path):
        df_existing = pd.read_csv(path)
        df = pd.concat([df_existing, df_new], ignore_index=True)
    else:
        df = df_new
    df.to_csv(path, index=False)
    load_csv.clear()


def load_scholarships() -> pd.DataFrame:
    df = load_csv("scholarships.csv")
    if df.empty:
        return df
    df["deadline"] = pd.to_datetime(df["deadline"], errors="coerce")
    return df


def load_universities() -> pd.DataFrame:
    return load_csv("universities.csv")


def load_grade_mapping() -> pd.DataFrame:
    return load_csv("grade_mapping.csv")


def load_countries() -> pd.DataFrame:
    return load_csv("countries.csv")


def load_subjects() -> pd.DataFrame:
    return load_csv("subjects.csv")


def load_candidates() -> pd.DataFrame:
    return load_csv("candidates.csv")
