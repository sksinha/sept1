import streamlit as st
import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_scholarships
from engine.competitiveness import calculate_competitiveness

st.set_page_config(page_title="Scholarship Explorer", page_icon="🔍", layout="wide")
st.title("🔍 Scholarship Explorer")

df = load_scholarships()

with st.sidebar:
    st.header("Filters")
    country = st.multiselect("Country", sorted(df["country"].unique()))
    university = st.multiselect("University", sorted(df["university"].unique()))
    degree = st.multiselect("Degree", sorted(df["degree_level"].dropna().unique()))
    subject = st.multiselect("Subject", sorted(df["subject"].dropna().unique()))
    funding_type = st.multiselect("Funding Type", sorted(df["funding_type"].dropna().unique()))
    intl_only = st.checkbox("International students eligible only")
    min_award = st.number_input("Minimum award amount ($ equiv.)", min_value=0, value=0, step=5000)
    deadline_after = st.date_input("Deadline after", value=None)

filtered = df.copy()
if country:
    filtered = filtered[filtered["country"].isin(country)]
if university:
    filtered = filtered[filtered["university"].isin(university)]
if degree:
    filtered = filtered[filtered["degree_level"].isin(degree)]
if subject:
    filtered = filtered[filtered["subject"].isin(subject)]
if funding_type:
    filtered = filtered[filtered["funding_type"].isin(funding_type)]
if intl_only:
    filtered = filtered[filtered["eligibility"].astype(str).str.contains("International students eligible")]
if min_award:
    filtered = filtered[filtered["amount"] >= min_award]
if deadline_after:
    filtered = filtered[filtered["deadline"] >= pd.Timestamp(deadline_after)]

st.caption(f"{len(filtered)} of {len(df)} scholarships match your filters.")

display_cols = ["university", "scholarship_name", "country", "degree_level", "funding_type",
                 "amount", "minimum_gpa", "deadline", "selection_rate", "source_url"]
st.dataframe(
    filtered[display_cols].rename(columns={
        "university": "University", "scholarship_name": "Scholarship", "country": "Country",
        "degree_level": "Degree", "funding_type": "Funding", "amount": "Amount",
        "minimum_gpa": "GPA", "deadline": "Deadline", "selection_rate": "Selection %", "source_url": "Source",
    }),
    use_container_width=True, hide_index=True,
)

st.divider()
st.subheader("Scholarship Detail")
if filtered.empty:
    st.info("No scholarships match the current filters.")
else:
    options = filtered.apply(lambda r: f"{r['scholarship_id']} — {r['university']} — {r['scholarship_name']}", axis=1)
    choice = st.selectbox("Select a scholarship to view full detail", options)
    sid = choice.split(" — ")[0]
    row = filtered[filtered["scholarship_id"] == sid].iloc[0]

    comp = calculate_competitiveness(row)

    colA, colB = st.columns([2, 1])
    with colA:
        st.markdown(f"### {row['scholarship_name']}")
        st.markdown(f"**{row['university']}**, {row['country']}")
        detail_fields = [
            ("Degree", row["degree_level"]), ("Subject", row["subject"]),
            ("Funding Type", row["funding_type"]), ("Funding Amount", f"{row['currency']} {row['amount']:,}"),
            ("Tuition Coverage", row["tuition_coverage"]), ("Living Stipend", row["living_stipend"]),
            ("Eligibility", row["eligibility"]), ("Minimum GPA / Band", row["minimum_gpa"]),
            ("English Requirement", row["language_requirement"]),
            ("Application Deadline", row["deadline"].strftime("%d %b %Y") if pd.notna(row["deadline"]) else "Not published"),
            ("Application Method", row["application_method"]),
            ("Number of Awards", row["number_of_awards"]),
            ("Applicant Count", row["applicant_count"] if pd.notna(row["applicant_count"]) else "Not publicly available"),
            ("Published/Calculated Selection Rate", comp.selection_rate_display),
            ("Last Verified", row["last_checked"]),
        ]
        for label, value in detail_fields:
            st.markdown(f"**{label}:** {value}")

        st.link_button("🔗 View Official Source", row["source_url"])

        status_colors = {
            "Verified Official Source": "🟢", "Official Source — Needs Review": "🟡",
            "Secondary Source": "🟠", "Unverified": "🔴", "Expired": "⚫",
        }
        st.markdown(f"**Verification Status:** {status_colors.get(row['verification_status'], '')} {row['verification_status']}")

    with colB:
        st.markdown("#### System Competitiveness Indicator")
        st.caption("System-generated competitiveness indicator — not an official university rating.")
        for key, val in comp.components.items():
            max_val = comp.max_components[key]
            st.markdown(f"{key.replace('_', ' ').title()}: **{val}/{max_val}**")
            st.progress(min(val / max_val, 1.0))
        st.markdown(f"### Total: {comp.total}/100")
