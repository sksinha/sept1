import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_scholarships, load_grade_mapping
from engine.eligibility import run_matching

st.set_page_config(page_title="Find Scholarships For Me", page_icon="🎯", layout="wide")
st.title("🎯 Find Scholarships For Me")

profile = st.session_state.get("candidate_profile")

if not profile:
    st.warning("No saved profile found. Go to **Student Profile** in the sidebar and save one first.")
    st.stop()

with st.expander("Using this profile", expanded=False):
    st.json(profile)

scholarships = load_scholarships()
grade_mapping = load_grade_mapping()

# The eligibility engine expects specific keys — remap from the profile.
candidate = {
    "degree_level": profile.get("degree_level"),
    "intended_subject": profile.get("intended_subject"),
    "citizenship_country": profile.get("citizenship_country"),
    "score_value": profile.get("score_value"),
    "score_type": profile.get("score_type"),
    "ielts": profile.get("ielts"),
    "toefl": profile.get("toefl"),
}

st.caption(
    "Matching is rules-based and deterministic — it checks published criteria against your profile. "
    "It never predicts admission or guarantees an award."
)

if st.button("🔎 Find Scholarships For Me", type="primary"):
    results = run_matching(candidate, scholarships, grade_mapping)

    status_order = {"Potentially Eligible": 0, "Needs Verification": 1, "Not Currently Matching": 2, "Deadline Passed": 3}
    results_sorted = sorted(results, key=lambda r: status_order.get(r.overall, 4))

    status_icons = {
        "Potentially Eligible": "✅", "Needs Verification": "⚠️",
        "Not Currently Matching": "❌", "Deadline Passed": "⏳",
    }
    check_icons = {"pass": "✓", "fail": "✗", "warning": "⚠"}

    summary_counts = {}
    for r in results:
        summary_counts[r.overall] = summary_counts.get(r.overall, 0) + 1

    cols = st.columns(4)
    for i, status in enumerate(["Potentially Eligible", "Needs Verification", "Not Currently Matching", "Deadline Passed"]):
        cols[i].metric(status, summary_counts.get(status, 0))

    st.divider()

    for r in results_sorted:
        row = scholarships[scholarships["scholarship_id"] == r.scholarship_id].iloc[0]
        with st.expander(f"{status_icons[r.overall]} {row['university']} — {row['scholarship_name']}  ·  **{r.overall}**"):
            c1, c2 = st.columns([1, 1])
            with c1:
                st.markdown(f"**Country:** {row['country']}  \n**Degree:** {row['degree_level']}  \n"
                            f"**Subject:** {row['subject']}  \n**Funding:** {row['funding_type']} ({row['currency']} {row['amount']:,})  \n"
                            f"**Deadline:** {row['deadline'].strftime('%d %b %Y') if row['deadline'] is not None else 'Unknown'}")
                st.link_button("🔗 Official Source", row["source_url"])
            with c2:
                st.markdown("**Eligibility Status**")
                for label, status in r.checks.items():
                    st.markdown(f"{check_icons[status]} {label}")
                st.markdown(f"**Overall: {r.overall}**")

    st.info(
        "Note: statuses reflect published/available criteria only. 'Needs Verification' means a required "
        "data point (e.g. your test score, or the scholarship's own eligibility text) was insufficient to "
        "confirm automatically — check the official source before applying."
    )
