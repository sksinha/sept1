import streamlit as st
import sys, os
from datetime import datetime
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_countries, load_subjects, append_row_csv

st.set_page_config(page_title="Student Profile", page_icon="🧑‍🎓", layout="wide")
st.title("🧑‍🎓 Student Profile")
st.caption("Save your profile here, then use **Find Scholarships For Me** to run it against the database.")

countries = load_countries()
subjects = load_subjects()

if "candidate_profile" not in st.session_state:
    st.session_state.candidate_profile = {}

with st.form("student_profile_form"):
    st.subheader("Identity & Target")
    c1, c2 = st.columns(2)
    with c1:
        name = st.text_input("Student name")
        citizenship_country = st.selectbox("Country of citizenship", ["India"] + sorted(countries["country"].unique().tolist()))
        target_country = st.selectbox("Target country", ["Any"] + sorted(countries["country"].unique().tolist()))
    with c2:
        degree_level = st.selectbox("Degree level", ["Undergraduate", "Master's", "MBA", "PhD"])
        intended_subject = st.selectbox("Intended subject", sorted(subjects["subject"].unique().tolist()))
        intake_year = st.number_input("Intended intake year", min_value=2026, max_value=2032, value=2027)

    st.subheader("Current Academic Profile")
    c3, c4, c5 = st.columns(3)
    with c3:
        current_qualification = st.text_input("Current qualification (e.g. B.Tech)")
        current_university = st.text_input("Current university")
    with c4:
        score_type = st.selectbox("Score type", ["Percentage", "GPA_4", "GPA_10", "UK_Class", "ECTS"])
        score_value = st.number_input("Score value", min_value=0.0, max_value=100.0, value=85.0)
    with c5:
        st.write("")

    st.subheader("Standardized Tests")
    t1, t2, t3, t4, t5, t6 = st.columns(6)
    ielts = t1.number_input("IELTS", min_value=0.0, max_value=9.0, value=0.0, step=0.5)
    toefl = t2.number_input("TOEFL", min_value=0, max_value=120, value=0)
    gre = t3.number_input("GRE", min_value=0, max_value=340, value=0)
    gmat = t4.number_input("GMAT", min_value=0, max_value=800, value=0)
    sat = t5.number_input("SAT", min_value=0, max_value=1600, value=0)
    act = t6.number_input("ACT", min_value=0, max_value=36, value=0)

    st.subheader("Experience & Background")
    e1, e2 = st.columns(2)
    with e1:
        research_experience = st.text_area("Research experience / publications")
        work_experience = st.text_area("Work experience")
    with e2:
        extracurricular = st.text_area("Extracurricular / leadership")
        financial_need = st.selectbox("Financial need", ["Not specified", "Low", "Moderate", "High"])

    gender = st.selectbox("Gender (only where relevant/required by a scholarship)", ["Prefer not to say", "Female", "Male", "Other"])

    submitted = st.form_submit_button("Save Profile")

if submitted:
    profile = {
        "name": name, "citizenship_country": citizenship_country, "target_country": target_country,
        "degree_level": degree_level, "intended_subject": intended_subject, "intake_year": intake_year,
        "current_qualification": current_qualification, "current_university": current_university,
        "score_type": score_type, "score_value": score_value,
        "ielts": ielts or None, "toefl": toefl or None, "gre": gre or None, "gmat": gmat or None,
        "sat": sat or None, "act": act or None,
        "research_experience": research_experience, "work_experience": work_experience,
        "extracurricular": extracurricular, "financial_need": financial_need, "gender": gender,
        "saved_at": datetime.now().isoformat(),
    }
    st.session_state.candidate_profile = profile
    try:
        append_row_csv(profile, "candidates.csv")
    except Exception as e:
        st.warning(f"Profile saved for this session but could not be written to disk: {e}")
    st.success("Profile saved. Go to **Find Scholarships For Me** in the sidebar to see matches.")

if st.session_state.candidate_profile:
    st.divider()
    st.subheader("Current Saved Profile")
    st.json(st.session_state.candidate_profile)
