import streamlit as st
import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_scholarships, load_universities

st.set_page_config(page_title="Dashboard", page_icon="📊", layout="wide")
st.title("📊 Dashboard")

scholarships = load_scholarships()
universities = load_universities()

c1, c2, c3, c4 = st.columns(4)
c1.metric("Universities", universities["university"].nunique())
c2.metric("Scholarships", len(scholarships))
c3.metric("Full Funding", int(scholarships["funding_type"].isin(["Full Scholarship", "Full Tuition"]).sum()))
c4.metric("Countries", scholarships["country"].nunique())

st.divider()
st.subheader("Additional KPIs")
d1, d2, d3, d4 = st.columns(4)
avg_amount = scholarships["amount"].mean()
d1.metric("Average Scholarship Amount", f"${avg_amount:,.0f}")

closing_this_month = scholarships[
    (scholarships["deadline"].dt.year == pd.Timestamp.now().year) &
    (scholarships["deadline"].dt.month == pd.Timestamp.now().month)
].shape[0]
d2.metric("Closing This Month", closing_this_month)

d3.metric("International-Student Eligible", int(scholarships["eligibility"].astype(str).str.contains("International students eligible").sum()))
d4.metric("No Published Selection Rate", int(scholarships["selection_rate"].isna().sum()))

e1, e2, e3 = st.columns(3)
e1.metric("PhD Scholarships", int((scholarships["degree_level"] == "PhD").sum()))
e2.metric("STEM Scholarships", int(scholarships["subject"].isin(["Computer Science", "AI / Data Science", "Engineering"]).sum()))
e3.metric("Medicine Scholarships", int(scholarships["subject"].isin(["Medicine", "Public Health"]).sum()))

st.divider()
st.subheader("Scholarships by Country")
st.bar_chart(scholarships["country"].value_counts())

st.subheader("Scholarships by Funding Type")
st.bar_chart(scholarships["funding_type"].value_counts())
