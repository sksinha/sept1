import streamlit as st
import pandas as pd
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_scholarships

st.set_page_config(page_title="Deadline Intelligence", page_icon="⏰", layout="wide")
st.title("⏰ Deadline Intelligence")

df = load_scholarships()
now = pd.Timestamp.now()
df = df.copy()
df["days_remaining"] = (df["deadline"] - now).dt.days

upcoming = df[df["days_remaining"] >= 0]
passed = df[df["days_remaining"] < 0]

c1, c2, c3, c4 = st.columns(4)
c1.metric("Next 7 days", int((upcoming["days_remaining"] <= 7).sum()))
c2.metric("Next 30 days", int((upcoming["days_remaining"] <= 30).sum()))
c3.metric("Next 60 days", int((upcoming["days_remaining"] <= 60).sum()))
c4.metric("Next 90 days", int((upcoming["days_remaining"] <= 90).sum()))

st.divider()


def urgency_badge(days):
    if days <= 14:
        return "🔴 Very Near"
    if days <= 45:
        return "🟡 Approaching"
    return "🟢 Sufficient Time"


st.subheader("Upcoming Deadlines")
upcoming_sorted = upcoming.sort_values("days_remaining")
display = upcoming_sorted[["university", "scholarship_name", "country", "deadline", "days_remaining", "application_method"]].copy()
display["Urgency"] = upcoming_sorted["days_remaining"].apply(urgency_badge)
display["deadline"] = display["deadline"].dt.strftime("%d %b %Y")
st.dataframe(
    display.rename(columns={
        "university": "University", "scholarship_name": "Scholarship", "country": "Country",
        "deadline": "Deadline", "days_remaining": "Days Remaining", "application_method": "Application Portal",
    }),
    use_container_width=True, hide_index=True,
)

with st.expander(f"Deadlines already passed ({len(passed)})"):
    if passed.empty:
        st.caption("None.")
    else:
        passed_display = passed[["university", "scholarship_name", "country", "deadline"]].copy()
        passed_display["deadline"] = passed_display["deadline"].dt.strftime("%d %b %Y")
        st.dataframe(passed_display, use_container_width=True, hide_index=True)

st.caption("Note: deadlines and application portals shown reflect the sample dataset's last-checked date. Always confirm timezone and exact cutoff time on the official source page before submitting.")
