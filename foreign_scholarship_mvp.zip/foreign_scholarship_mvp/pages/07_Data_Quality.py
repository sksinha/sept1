import streamlit as st
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_scholarships
from engine.data_quality import flag_missing, flag_stale, flag_duplicates, build_data_quality_summary

st.set_page_config(page_title="Data Quality", page_icon="🧪", layout="wide")
st.title("🧪 Data Quality")

df = load_scholarships()
summary = build_data_quality_summary(df)

c1, c2, c3 = st.columns(3)
c1.metric("Total Records", summary["total_records"])
c2.metric("Official Source", summary["official_source"])
c3.metric("Secondary Source", summary["secondary_source"])

c4, c5, c6 = st.columns(3)
c4.metric("Manual Verification Required", summary["manual_verification_required"])
c5.metric("Checked < 7 days", summary["checked_lt_7_days"])
c6.metric("Checked > 30 days", summary["checked_gt_30_days"])

st.divider()
st.subheader("Flagged Records")

missing_flags = flag_missing(df)
stale_flags = flag_stale(df)
dup_flags = flag_duplicates(df)

flagged = df.copy()
flagged["missing_field(s)"] = missing_flags.apply(
    lambda r: ", ".join([c.replace("missing_", "") for c in r.index if r[c]]), axis=1
)
flagged["stale_source"] = stale_flags
flagged["possible_duplicate"] = dup_flags

issues = flagged[
    (flagged["missing_field(s)"] != "") | flagged["stale_source"] | flagged["possible_duplicate"]
]

if issues.empty:
    st.success("No data quality issues flagged in the current dataset.")
else:
    st.warning(f"{len(issues)} record(s) flagged for review.")
    st.dataframe(
        issues[["scholarship_id", "university", "scholarship_name", "missing_field(s)",
                "stale_source", "possible_duplicate", "verification_status", "last_checked", "source_url"]],
        use_container_width=True, hide_index=True,
    )

st.divider()
st.subheader("Verification Status Breakdown")
st.bar_chart(df["verification_status"].value_counts())
