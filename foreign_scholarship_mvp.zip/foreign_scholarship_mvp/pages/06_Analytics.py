import streamlit as st
import pandas as pd
import plotly.express as px
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
from utils.csv_utils import load_scholarships

st.set_page_config(page_title="Analytics", page_icon="📈", layout="wide")
st.title("📈 Analytics")

df = load_scholarships()

col1, col2 = st.columns(2)
with col1:
    st.subheader("Scholarships by Country")
    fig = px.bar(df["country"].value_counts().reset_index(), x="country", y="count",
                 labels={"country": "Country", "count": "Scholarships"})
    st.plotly_chart(fig, use_container_width=True)

with col2:
    st.subheader("Scholarships by Degree")
    fig = px.pie(df, names="degree_level", title=None)
    st.plotly_chart(fig, use_container_width=True)

col3, col4 = st.columns(2)
with col3:
    st.subheader("Scholarships by Subject")
    fig = px.bar(df["subject"].value_counts().reset_index(), x="subject", y="count",
                 labels={"subject": "Subject", "count": "Scholarships"})
    st.plotly_chart(fig, use_container_width=True)

with col4:
    st.subheader("Full vs Partial Funding")
    full_mask = df["funding_type"].isin(["Full Scholarship", "Full Tuition"])
    funding_summary = pd.Series({"Full Funding": full_mask.sum(), "Partial/Other Funding": (~full_mask).sum()})
    fig = px.pie(values=funding_summary.values, names=funding_summary.index)
    st.plotly_chart(fig, use_container_width=True)

st.subheader("Scholarship Amount Distribution")
fig = px.histogram(df, x="amount", nbins=20, labels={"amount": "Amount (USD equivalent)"})
st.plotly_chart(fig, use_container_width=True)

st.subheader("Deadlines by Month")
month_counts = df["deadline"].dt.to_period("M").astype(str).value_counts().sort_index()
fig = px.bar(x=month_counts.index, y=month_counts.values, labels={"x": "Month", "y": "Scholarships Closing"})
st.plotly_chart(fig, use_container_width=True)

col5, col6 = st.columns(2)
with col5:
    st.subheader("International-Student Scholarships")
    intl = df["eligibility"].astype(str).str.contains("International students eligible")
    intl_summary = pd.Series({"International Eligible": intl.sum(), "Domestic Only": (~intl).sum()})
    fig = px.pie(values=intl_summary.values, names=intl_summary.index)
    st.plotly_chart(fig, use_container_width=True)

with col6:
    st.subheader("Published Selection Rates")
    has_rate = df["selection_rate"].notna()
    rate_summary = pd.Series({"Published": has_rate.sum(), "Not Publicly Available": (~has_rate).sum()})
    fig = px.pie(values=rate_summary.values, names=rate_summary.index)
    st.plotly_chart(fig, use_container_width=True)

col7, col8 = st.columns(2)
with col7:
    st.subheader("Funding by Country (Average Amount)")
    avg_by_country = df.groupby("country")["amount"].mean().sort_values(ascending=False).reset_index()
    fig = px.bar(avg_by_country, x="country", y="amount", labels={"country": "Country", "amount": "Avg Amount"})
    st.plotly_chart(fig, use_container_width=True)

with col8:
    st.subheader("Funding by University (Average Amount)")
    avg_by_uni = df.groupby("university")["amount"].mean().sort_values(ascending=False).reset_index()
    fig = px.bar(avg_by_uni, x="university", y="amount", labels={"university": "University", "amount": "Avg Amount"})
    fig.update_xaxes(tickangle=45)
    st.plotly_chart(fig, use_container_width=True)

st.caption("Note: 'Published Selection Rates' reflects records where applicant_count was available to calculate a ratio, not necessarily an officially published university acceptance rate.")
