import streamlit as st
import pandas as pd
import sys, os

sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from utils.csv_utils import load_scholarships, load_universities, load_countries, load_subjects

st.set_page_config(
    page_title="Global University Scholarship Intelligence",
    page_icon="🎓",
    layout="wide",
)

st.markdown(
    """
    <style>
    .hero-box {
        background: linear-gradient(135deg, #1e3a5f 0%, #2c5282 100%);
        padding: 2rem 2.5rem; border-radius: 12px; color: white; margin-bottom: 1.5rem;
    }
    .hero-box h1 { margin-bottom: 0.2rem; font-size: 1.9rem; }
    .hero-box p { opacity: 0.9; margin-top: 0; }
    .kpi-card {
        background: #f7f9fc; border: 1px solid #e2e8f0; border-radius: 10px;
        padding: 1rem; text-align: center;
    }
    .kpi-number { font-size: 1.8rem; font-weight: 700; color: #1e3a5f; }
    .kpi-label { color: #4a5568; font-size: 0.85rem; }
    .disclaimer-box {
        background: #fff8e1; border-left: 4px solid #f6ad55; padding: 0.75rem 1rem;
        border-radius: 6px; font-size: 0.85rem; color: #7b5e00; margin: 1rem 0;
    }
    </style>
    """,
    unsafe_allow_html=True,
)

st.markdown(
    """
    <div class="hero-box">
        <h1>🎓 Global University Scholarship Intelligence</h1>
        <p>Find • Compare • Verify • Match • Track — foreign university scholarships, grounded in official sources.</p>
    </div>
    """,
    unsafe_allow_html=True,
)

scholarships = load_scholarships()
universities = load_universities()
countries = load_countries()
subjects = load_subjects()

# ---- Top KPIs -----------------------------------------------------------
c1, c2, c3, c4 = st.columns(4)
with c1:
    st.markdown(f'<div class="kpi-card"><div class="kpi-number">{universities["university"].nunique()}</div>'
                f'<div class="kpi-label">Universities</div></div>', unsafe_allow_html=True)
with c2:
    st.markdown(f'<div class="kpi-card"><div class="kpi-number">{len(scholarships)}</div>'
                f'<div class="kpi-label">Scholarships</div></div>', unsafe_allow_html=True)
with c3:
    full_funding = scholarships["funding_type"].isin(["Full Scholarship", "Full Tuition"]).sum()
    st.markdown(f'<div class="kpi-card"><div class="kpi-number">{full_funding}</div>'
                f'<div class="kpi-label">Full Funding</div></div>', unsafe_allow_html=True)
with c4:
    st.markdown(f'<div class="kpi-card"><div class="kpi-number">{scholarships["country"].nunique()}</div>'
                f'<div class="kpi-label">Countries</div></div>', unsafe_allow_html=True)

st.markdown(
    '<div class="disclaimer-box">⚠️ This is an MVP demo populated with <b>sample data</b> for illustration. '
    'Amounts, deadlines and selection rates shown are placeholders, not verified live figures. '
    'Use the Data Quality page to see source/verification status for every record before relying on it. '
    'Selection-rate and competitiveness figures are <b>system-generated estimates</b>, never official university statistics, '
    'unless a record is explicitly marked as a published official rate.</div>',
    unsafe_allow_html=True,
)

st.divider()

# ---- Quick search ---------------------------------------------------------
st.subheader("Quick Search")
qs1, qs2, qs3, qs4 = st.columns(4)
with qs1:
    country_sel = st.selectbox("Country", ["All"] + sorted(countries["country"].unique().tolist()))
with qs2:
    degree_sel = st.selectbox("Degree", ["All"] + sorted(scholarships["degree_level"].dropna().unique().tolist()))
with qs3:
    subject_sel = st.selectbox("Subject", ["All"] + sorted(subjects["subject"].unique().tolist()))
with qs4:
    funding_sel = st.selectbox("Funding", ["All"] + sorted(scholarships["funding_type"].dropna().unique().tolist()))

filtered = scholarships.copy()
if country_sel != "All":
    filtered = filtered[filtered["country"] == country_sel]
if degree_sel != "All":
    filtered = filtered[filtered["degree_level"] == degree_sel]
if subject_sel != "All":
    filtered = filtered[filtered["subject"] == subject_sel]
if funding_sel != "All":
    filtered = filtered[filtered["funding_type"] == funding_sel]

st.caption(f"{len(filtered)} matching scholarships. Open **Scholarship Explorer** in the sidebar for full filtering and detail pages.")
st.dataframe(
    filtered[["university", "scholarship_name", "country", "degree_level", "funding_type", "amount", "deadline"]]
    .sort_values("deadline")
    .head(10),
    use_container_width=True, hide_index=True,
)

st.divider()
st.subheader("Scholarship Intelligence at a Glance")
i1, i2, i3, i4, i5 = st.columns(5)
i1.metric("Full funding", int((scholarships["funding_type"] == "Full Scholarship").sum()))
i2.metric("Partial funding", int(scholarships["funding_type"].isin(["Partial Tuition", "Tuition Waiver"]).sum()))
intl = scholarships["eligibility"].astype(str).str.contains("International students eligible").sum()
i3.metric("International-eligible", int(intl))
this_month_count = scholarships[
    (scholarships["deadline"].dt.year == pd.Timestamp.now().year) &
    (scholarships["deadline"].dt.month == pd.Timestamp.now().month)
].shape[0]
i4.metric("Deadlines this month", this_month_count)
published = scholarships["selection_rate"].notna().sum()
i5.metric("Published selection rates", int(published))

st.divider()
st.markdown(
    "Use the sidebar to open **Dashboard**, **Scholarship Explorer**, **Student Profile**, "
    "**Find Scholarships For Me**, **Deadlines**, **Analytics**, or **Data Quality**."
)
