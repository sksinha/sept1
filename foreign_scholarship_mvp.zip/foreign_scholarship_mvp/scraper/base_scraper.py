"""
Base scraper: shared request handling with rate-limiting and robots.txt
respect. This module intentionally does NOT attempt to bypass CAPTCHAs,
logins, or access controls. For pages that block automated access
(most modern JS-heavy university sites), use the manual ingestion path
in university_scraper.manual_ingest() instead.
"""
import time
import urllib.robotparser as robotparser
from urllib.parse import urlparse
import requests

USER_AGENT = "ForeignScholarshipMVP-Bot/0.1 (+contact: set-your-contact-email-here)"
MIN_REQUEST_INTERVAL_SECONDS = 3  # polite default crawl delay


class RobotsBlocked(Exception):
    pass


def _robots_url(url: str) -> str:
    parsed = urlparse(url)
    return f"{parsed.scheme}://{parsed.netloc}/robots.txt"


def is_allowed(url: str, user_agent: str = USER_AGENT) -> bool:
    rp = robotparser.RobotFileParser()
    try:
        rp.set_url(_robots_url(url))
        rp.read()
    except Exception:
        # If robots.txt can't be read, default to NOT crawling automatically —
        # fall back to manual ingestion instead of assuming permission.
        return False
    return rp.can_fetch(user_agent, url)


_last_request_time = {}


def polite_get(url: str, timeout: int = 15):
    """
    Fetch a URL only if robots.txt allows it, with a minimum interval
    between requests to the same host. Raises RobotsBlocked if disallowed.
    """
    if not is_allowed(url):
        raise RobotsBlocked(f"robots.txt disallows automated access to {url}")

    host = urlparse(url).netloc
    now = time.time()
    last = _last_request_time.get(host, 0)
    wait = MIN_REQUEST_INTERVAL_SECONDS - (now - last)
    if wait > 0:
        time.sleep(wait)

    resp = requests.get(url, headers={"User-Agent": USER_AGENT}, timeout=timeout)
    _last_request_time[host] = time.time()
    return resp
