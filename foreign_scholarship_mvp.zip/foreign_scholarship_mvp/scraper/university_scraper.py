"""
University scraper: thin orchestration layer over base_scraper. For sites
that are JS-rendered, gated, or otherwise resist polite automated access,
use manual_ingest() to record a human-copied snapshot instead of attempting
to bypass any access control.
"""
from datetime import datetime
from .base_scraper import polite_get, RobotsBlocked
from .parser import parse_scholarship_page


def scrape_university_page(url: str) -> dict:
    """
    Attempts an automated, robots.txt-respecting fetch + parse.
    Returns a dict with a 'status' field: 'ok', 'blocked', or 'error'.
    """
    try:
        resp = polite_get(url)
    except RobotsBlocked as e:
        return {"status": "blocked", "message": str(e), "source_url": url}
    except Exception as e:
        return {"status": "error", "message": str(e), "source_url": url}

    if resp.status_code != 200:
        return {"status": "error", "message": f"HTTP {resp.status_code}", "source_url": url}

    parsed = parse_scholarship_page(resp.text)
    parsed["source_url"] = url
    parsed["retrieved_at"] = datetime.now().isoformat()
    parsed["status"] = "ok"
    return parsed


def manual_ingest(url: str, fields: dict) -> dict:
    """
    Records a manually-verified scholarship record. `fields` should be a
    dict of scholarship.csv columns as copied by a human reviewer from the
    official page. This is the recommended path for JS-heavy or
    access-controlled university sites (spec section 9).
    """
    record = dict(fields)
    record["source_url"] = url
    record["last_checked"] = datetime.now().strftime("%Y-%m-%d")
    record["verification_status"] = record.get("verification_status", "Official Source — Needs Review")
    return record
