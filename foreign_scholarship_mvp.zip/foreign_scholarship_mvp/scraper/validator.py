"""
Source validator: sanity-checks a candidate record before it's allowed
into the main dataset.
"""
from urllib.parse import urlparse

OFFICIAL_DOMAIN_HINTS = [".edu", "ac.uk", "ac.jp", "edu.sg", "edu.au"]


def looks_official(url: str) -> bool:
    netloc = urlparse(url).netloc.lower()
    return any(hint in netloc for hint in OFFICIAL_DOMAIN_HINTS)


def validate_record(record: dict) -> list:
    """Returns a list of validation warning strings (empty = no issues)."""
    warnings = []
    url = record.get("source_url", "")
    if not url:
        warnings.append("Missing source_url.")
    elif not looks_official(url):
        warnings.append("Source domain does not look like an official university/government domain — flag as Secondary Source.")
    if not record.get("deadline") and not record.get("deadline_candidate"):
        warnings.append("No deadline found — mark as missing rather than guessing.")
    if not record.get("amount") and not record.get("amount_candidate"):
        warnings.append("No funding amount found — mark as missing rather than guessing.")
    return warnings
