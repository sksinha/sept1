"""
Very small heuristic parser for scholarship pages. Given raw HTML, tries
to pull out obvious candidate fields (deadlines, amounts). This is
intentionally conservative: anything it cannot find with reasonable
confidence is left blank rather than guessed, and the resulting record
should always be routed through manual review before being trusted.
"""
import re
from bs4 import BeautifulSoup

AMOUNT_RE = re.compile(r"(USD|GBP|EUR|CAD|AUD|SGD|JPY|\$|£|€)\s?[\d,]+")
DEADLINE_RE = re.compile(
    r"(January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}"
)


def parse_scholarship_page(html: str) -> dict:
    soup = BeautifulSoup(html, "html.parser")
    text = soup.get_text(separator=" ", strip=True)

    title = soup.title.string.strip() if soup.title and soup.title.string else ""
    amount_match = AMOUNT_RE.search(text)
    deadline_match = DEADLINE_RE.search(text)

    return {
        "source_title": title,
        "amount_candidate": amount_match.group(0) if amount_match else "",
        "deadline_candidate": deadline_match.group(0) if deadline_match else "",
        "verification_status": "Unverified",
        "note": "Auto-extracted candidates only — requires manual verification before use.",
    }
