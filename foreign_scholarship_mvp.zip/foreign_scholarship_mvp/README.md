# Global University Scholarship Intelligence Dashboard (MVP)

A Streamlit application for discovering and comparing foreign university
scholarships, built around transparent, source-verifiable data — never
invented numbers.

## What's included in this MVP

- **Landing page + Dashboard** — headline KPIs (universities, scholarships,
  full-funding count, countries) plus deeper KPIs (average amount, deadlines
  this month, STEM/Medicine/PhD counts, etc.)
- **Scholarship Explorer** — full filterable table + click-through detail
  page showing every field from the spec (funding, eligibility, deadline,
  source, verification status) plus a transparent competitiveness
  breakdown.
- **Student Profile** — captures the candidate profile fields from the spec
  and saves them to `data/candidates.csv`.
- **Find Scholarships For Me** — a **deterministic rules engine** (not AI)
  that checks a saved profile against every scholarship and returns one of:
  `Potentially Eligible / Needs Verification / Not Currently Matching /
  Deadline Passed` — never a promise of admission or an award.
- **Deadline Intelligence** — 7/30/60/90-day buckets with red/yellow/green
  urgency badges.
- **Analytics** — Plotly charts: by country, degree, subject, funding split,
  amount distribution, deadlines by month, international eligibility,
  published-selection-rate coverage, and average funding by country/university.
- **Data Quality** — record counts by source type and verification status,
  and a flagged-records view (missing fields, stale `last_checked` dates,
  possible duplicates).
- **Grade Normalization Engine** (`engine/grade_normalizer.py`) — converts a
  reported score into a normalized band using the editable
  `data/grade_mapping.csv` table. It never assumes GPA/percentage systems
  are universally equivalent, and returns "manual review required" rather
  than guessing when nothing matches.
- **Competitiveness Engine** (`engine/competitiveness.py`) — calculates a
  **Selection Ratio** only when applicant counts are known (otherwise
  displays "Not publicly available" — it never invents a percentage), and a
  fully transparent 0–100 **System Competitiveness Indicator** with every
  weighted component shown, explicitly labeled as a system estimate, not an
  official university statistic.
- **Scraper module** (`scraper/`) — a robots.txt-respecting, rate-limited
  fetcher (`base_scraper.py`), a thin parser that only extracts obvious
  candidate fields and marks them `Unverified` (`parser.py`), a source
  validator (`validator.py`), and a **manual ingestion path**
  (`university_scraper.manual_ingest()`) for the many university sites that
  are JS-rendered or otherwise resist polite automated access. The scraper
  is an *optional* ingestion capability — the dashboard runs entirely from
  the bundled sample CSVs and needs no internet connection to start.

## Not included in this MVP (by design)

- Live web scraping is stubbed/optional, not wired into a scheduled job
  (see `scraper/scheduler.py` — intentionally omitted; add one with
  `APScheduler` or a cron/Task Scheduler entry if you want it).
- The RAG/LLM layer (spec section 21) is a Version 2 item. The eligibility
  and competitiveness logic here is deliberately deterministic and rule-based.
- PostgreSQL migration — MVP uses flat CSV files in `data/`, matching the
  spec's "Data Storage" section.
- PDF report export (ReportLab is in `requirements.txt` as a placeholder for
  this Version 1.1 addition — not yet wired into the UI).

## Project structure

```
foreign_scholarship_mvp/
├── app.py                      # Landing page (multipage entry point)
├── requirements.txt
├── README.md
├── data/                       # Sample CSV dataset (works fully offline)
│   ├── universities.csv
│   ├── scholarships.csv        # 42 sample scholarship records
│   ├── grade_mapping.csv
│   ├── countries.csv
│   ├── subjects.csv
│   └── candidates.csv          # created on first "Save Profile"
├── pages/
│   ├── 01_Dashboard.py
│   ├── 02_Scholarship_Explorer.py
│   ├── 03_Student_Profile.py
│   ├── 04_Find_Scholarships.py
│   ├── 05_Deadlines.py
│   ├── 06_Analytics.py
│   └── 07_Data_Quality.py
├── engine/
│   ├── grade_normalizer.py
│   ├── competitiveness.py
│   ├── eligibility.py          # matching engine
│   └── data_quality.py
├── scraper/
│   ├── base_scraper.py         # robots.txt + rate limiting
│   ├── university_scraper.py   # orchestration + manual_ingest()
│   ├── parser.py                # heuristic field extraction
│   └── validator.py
└── utils/
    └── csv_utils.py
```

## Installation

```bash
cd foreign_scholarship_mvp
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
```

## Running

```bash
streamlit run app.py
```

This opens the app at `http://localhost:8501`. It works fully offline using
the bundled sample dataset — no scraping or internet access is required to
explore the dashboard.

## Adding your own data

- **Add a university or country** without touching code: append a row to
  `data/universities.csv` (and `data/countries.csv` if it's a new country).
- **Add a scholarship**: append a row to `data/scholarships.csv` following
  the existing column headers. Set `verification_status` to
  `"Official Source — Needs Review"` until a human confirms it against the
  official page.
- **Add/adjust a grade conversion**: edit `data/grade_mapping.csv`. Each row
  defines a `(country, input_type)` range → `normalized_band` mapping. Rows
  are looked up by country first, falling back to the generic row for that
  `input_type` if no country-specific row exists.
- **Ingest from a new source manually** (recommended for JS-heavy sites):
  ```python
  from scraper.university_scraper import manual_ingest
  record = manual_ingest(
      url="https://example.edu/scholarships/merit-award",
      fields={"university": "...", "scholarship_name": "...", ...},
  )
  # then append `record` as a row to data/scholarships.csv after review
  ```

## Data integrity principles baked into the code

1. Selection rates and competitiveness scores are computed only from data
   present in the record — no fabricated numbers (`competitiveness.py`).
2. Grade conversions come from an editable, inspectable table, and the code
   returns "manual review required" rather than a guess when nothing matches
   (`grade_normalizer.py`).
3. Eligibility results are limited to four explicit labels and never claim
   a guaranteed outcome (`eligibility.py`).
4. The data-quality page never silently fills missing values — it only
   flags them (`data_quality.py`).
5. The scraper refuses to fetch a page robots.txt disallows, and never
   attempts to bypass CAPTCHAs or login walls — it hands off to manual
   ingestion instead (`scraper/base_scraper.py`).

## Sample data disclaimer

The bundled `data/*.csv` files contain **illustrative sample data** for demo
purposes — amounts, deadlines, applicant counts and selection rates are
plausible placeholders, not verified live figures. Before using this for
real advising, replace them with data collected and verified against each
university's official scholarship page.
