"""
Data Quality Engine
---------------------
Flags missing fields, stale verification, and duplicate-looking records.
Never silently fills in missing data (spec section 19) — everything here
only reports/flags, it never guesses a replacement value.
"""
from datetime import datetime
import pandas as pd


REQUIRED_FIELDS = ["deadline", "amount", "eligibility", "source_url"]


def flag_missing(df: pd.DataFrame) -> pd.DataFrame:
    flags = pd.DataFrame(index=df.index)
    for field in REQUIRED_FIELDS:
        if field in df.columns:
            flags[f"missing_{field}"] = df[field].isna() | (df[field].astype(str).str.strip() == "")
    return flags


def flag_stale(df: pd.DataFrame, days_threshold: int = 30, as_of=None) -> pd.Series:
    as_of = as_of or datetime.now()
    if "last_checked" not in df.columns:
        return pd.Series(False, index=df.index)
    last_checked = pd.to_datetime(df["last_checked"], errors="coerce")
    age_days = (as_of - last_checked).dt.days
    return age_days > days_threshold


def flag_duplicates(df: pd.DataFrame) -> pd.Series:
    if not {"university", "scholarship_name"}.issubset(df.columns):
        return pd.Series(False, index=df.index)
    return df.duplicated(subset=["university", "scholarship_name"], keep=False)


def build_data_quality_summary(df: pd.DataFrame) -> dict:
    if df.empty:
        return {
            "total_records": 0, "official_source": 0, "secondary_source": 0,
            "manual_verification_required": 0, "checked_lt_7_days": 0,
            "checked_7_30_days": 0, "checked_gt_30_days": 0,
        }

    total = len(df)
    verification = df.get("verification_status", pd.Series(dtype=str))
    official = (verification == "Verified Official Source").sum()
    secondary = (verification == "Secondary Source").sum()
    manual_review = verification.isin(["Official Source — Needs Review", "Unverified"]).sum()

    last_checked = pd.to_datetime(df.get("last_checked"), errors="coerce")
    age_days = (datetime.now() - last_checked).dt.days
    lt7 = (age_days < 7).sum()
    d7_30 = ((age_days >= 7) & (age_days <= 30)).sum()
    gt30 = (age_days > 30).sum()

    return {
        "total_records": total,
        "official_source": int(official),
        "secondary_source": int(secondary),
        "manual_verification_required": int(manual_review),
        "checked_lt_7_days": int(lt7),
        "checked_7_30_days": int(d7_30),
        "checked_gt_30_days": int(gt30),
    }
