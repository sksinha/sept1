"""
Scholarship Competitiveness Engine
------------------------------------
Produces:
  1. A "Selection Ratio" — ONLY calculated when applicant_count is known.
     Never invented. Displayed as "Not publicly available" otherwise.
  2. A "System Competitiveness Indicator" (0-100) with a fully visible
     component breakdown, per spec section 7. This is explicitly labelled
     as a system-generated estimate, never as an official university figure.
"""
from dataclasses import dataclass, field
from typing import Optional, Dict
import pandas as pd

WEIGHTS = {
    "academic_requirement": 25,
    "competition": 20,
    "funding": 15,
    "awards": 15,
    "eligibility_breadth": 10,
    "application_complexity": 5,
    "research": 10,
}


@dataclass
class CompetitivenessResult:
    components: Dict[str, float] = field(default_factory=dict)
    max_components: Dict[str, float] = field(default_factory=lambda: dict(WEIGHTS))
    total: float = 0.0
    max_total: float = 100.0
    selection_rate_display: str = "Not publicly available"


def calculate_selection_rate(number_of_awards, applicant_count) -> Optional[float]:
    """Returns a percentage, or None if applicant data isn't published."""
    try:
        awards = float(number_of_awards)
        applicants = float(applicant_count)
        if applicants <= 0:
            return None
        return round(awards / applicants * 100, 2)
    except (TypeError, ValueError):
        return None


def _score_academic_requirement(min_gpa_text: str) -> float:
    if not isinstance(min_gpa_text, str) or not min_gpa_text.strip():
        return WEIGHTS["academic_requirement"] * 0.5
    text = min_gpa_text.lower()
    if "no fixed minimum" in text:
        return WEIGHTS["academic_requirement"] * 0.4
    if "top 10%" in text or "3.7" in text or "3.8" in text or "3.9" in text:
        return WEIGHTS["academic_requirement"] * 1.0
    if "3.5" in text or "3.6" in text:
        return WEIGHTS["academic_requirement"] * 0.85
    return WEIGHTS["academic_requirement"] * 0.65


def _score_competition(selection_rate: Optional[float]) -> float:
    if selection_rate is None:
        return WEIGHTS["competition"] * 0.5  # unknown -> neutral midpoint
    if selection_rate <= 3:
        return WEIGHTS["competition"] * 1.0
    if selection_rate <= 8:
        return WEIGHTS["competition"] * 0.85
    if selection_rate <= 15:
        return WEIGHTS["competition"] * 0.65
    if selection_rate <= 30:
        return WEIGHTS["competition"] * 0.45
    return WEIGHTS["competition"] * 0.25


def _score_funding(funding_type: str, amount) -> float:
    full_types = {"Full Scholarship", "Full Tuition"}
    if funding_type in full_types:
        return WEIGHTS["funding"] * 1.0
    if funding_type in {"Tuition Waiver", "Fellowship", "Assistantship"}:
        return WEIGHTS["funding"] * 0.8
    if funding_type in {"Partial Tuition", "Living Stipend", "Merit Award", "Mixed Funding"}:
        return WEIGHTS["funding"] * 0.55
    return WEIGHTS["funding"] * 0.4


def _score_awards(number_of_awards) -> float:
    try:
        n = float(number_of_awards)
    except (TypeError, ValueError):
        return WEIGHTS["awards"] * 0.5
    if n <= 10:
        return WEIGHTS["awards"] * 1.0
    if n <= 25:
        return WEIGHTS["awards"] * 0.8
    if n <= 50:
        return WEIGHTS["awards"] * 0.6
    return WEIGHTS["awards"] * 0.4


def _score_eligibility_breadth(eligibility_text: str) -> float:
    if not isinstance(eligibility_text, str):
        return WEIGHTS["eligibility_breadth"] * 0.5
    if "international students eligible" in eligibility_text.lower():
        return WEIGHTS["eligibility_breadth"] * 0.6  # broader pool -> slightly more competitive-feeling
    return WEIGHTS["eligibility_breadth"] * 0.4


def _score_application_complexity(application_method: str) -> float:
    if not isinstance(application_method, str):
        return WEIGHTS["application_complexity"] * 0.5
    if "automatic" in application_method.lower():
        return WEIGHTS["application_complexity"] * 0.3
    if "nomination" in application_method.lower():
        return WEIGHTS["application_complexity"] * 1.0
    return WEIGHTS["application_complexity"] * 0.7


def _score_research(merit_level: str, degree_level: str) -> float:
    if isinstance(merit_level, str) and "Research" in merit_level:
        return WEIGHTS["research"] * 1.0
    if isinstance(degree_level, str) and degree_level in {"PhD", "Master's"}:
        return WEIGHTS["research"] * 0.6
    return WEIGHTS["research"] * 0.3


def calculate_competitiveness(scholarship: pd.Series) -> CompetitivenessResult:
    """
    Builds a transparent, component-level competitiveness score for a
    single scholarship record (a row from scholarships.csv).
    """
    selection_rate = calculate_selection_rate(
        scholarship.get("number_of_awards"), scholarship.get("applicant_count")
    )

    components = {
        "academic_requirement": round(_score_academic_requirement(scholarship.get("minimum_gpa", "")), 1),
        "competition": round(_score_competition(selection_rate), 1),
        "funding": round(_score_funding(scholarship.get("funding_type", ""), scholarship.get("amount")), 1),
        "awards": round(_score_awards(scholarship.get("number_of_awards")), 1),
        "eligibility_breadth": round(_score_eligibility_breadth(scholarship.get("eligibility", "")), 1),
        "application_complexity": round(_score_application_complexity(scholarship.get("application_method", "")), 1),
        "research": round(_score_research(scholarship.get("merit_level", ""), scholarship.get("degree_level", "")), 1),
    }
    total = round(sum(components.values()), 1)

    if selection_rate is not None:
        rate_display = f"{selection_rate}%"
    else:
        rate_display = "Not publicly available"

    return CompetitivenessResult(
        components=components,
        total=total,
        selection_rate_display=rate_display,
    )
