"""
Grade Normalization Engine
---------------------------
Converts a reported academic score (percentage, GPA on various scales,
UK classification, ECTS, etc.) into a transparent "normalized band"
using a configurable, editable lookup table (data/grade_mapping.csv).

Design principle (per spec section 5): this module NEVER assumes all
scoring systems are universally equivalent. Every conversion shows
which mapping row was used and what its source/notes are, so a human
can see exactly why a band was assigned and override it.
"""
from dataclasses import dataclass
from typing import Optional
import pandas as pd


@dataclass
class NormalizationResult:
    input_value: float
    input_type: str
    matched: bool
    normalized_band: Optional[str] = None
    education_system: Optional[str] = None
    notes: Optional[str] = None
    source: Optional[str] = None
    message: Optional[str] = None


def normalize_grade(
    value: float,
    input_type: str,
    grade_mapping: pd.DataFrame,
    country: Optional[str] = None,
) -> NormalizationResult:
    """
    Look up `value` (of the given `input_type`, e.g. 'Percentage', 'GPA_4',
    'GPA_10', 'UK_Class', 'ECTS') against the grade_mapping table.

    If a country-specific mapping exists it is preferred; otherwise the
    generic mapping for that input_type is used. If nothing matches, the
    function returns matched=False rather than guessing.
    """
    if grade_mapping is None or grade_mapping.empty:
        return NormalizationResult(value, input_type, False, message="Grade mapping table not loaded.")

    subset = grade_mapping[grade_mapping["input_type"] == input_type]
    if subset.empty:
        return NormalizationResult(
            value, input_type, False,
            message=f"No conversion table available for input type '{input_type}'. Manual review required.",
        )

    if country:
        country_subset = subset[subset["country"].str.lower() == country.lower()]
        if not country_subset.empty:
            subset = country_subset

    row = subset[(subset["minimum"] <= value) & (value <= subset["maximum"])]
    if row.empty:
        return NormalizationResult(
            value, input_type, False,
            message="Value falls outside the configured ranges. Manual review required.",
        )

    r = row.iloc[0]
    return NormalizationResult(
        input_value=value,
        input_type=input_type,
        matched=True,
        normalized_band=r["normalized_band"],
        education_system=r["education_system"],
        notes=r.get("notes", ""),
        source=r.get("source", ""),
    )


BAND_ORDER = ["Below Average", "Average", "Merit", "High Merit", "Exceptional"]


def band_rank(band: Optional[str]) -> int:
    try:
        return BAND_ORDER.index(band)
    except (ValueError, TypeError):
        return -1
