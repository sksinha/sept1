"""
Student Matching / Eligibility Engine
---------------------------------------
Deterministic, rules-based. Deliberately NOT AI-driven (per spec section 21 —
AI is never responsible for the core eligibility calculation).

For each scholarship the engine checks a fixed set of criteria and returns a
per-criterion status plus an overall verdict drawn ONLY from:
    Potentially Eligible | Needs Verification | Not Currently Matching | Deadline Passed
It never states that a student "will" receive an award.
"""
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, List, Optional
import pandas as pd

from engine.grade_normalizer import normalize_grade, band_rank

CHECK_LABELS = {
    "degree": "Degree requirement",
    "subject": "Subject requirement",
    "country_eligibility": "Country / international eligibility",
    "academic": "Academic requirement",
    "english": "English requirement",
    "deadline": "Deadline",
}


@dataclass
class MatchResult:
    scholarship_id: str
    checks: Dict[str, str] = field(default_factory=dict)  # label -> "pass" | "fail" | "warning"
    overall: str = "Needs Verification"
    notes: List[str] = field(default_factory=list)


def _check_degree(candidate: dict, scholarship: pd.Series) -> str:
    target = candidate.get("degree_level")
    if not target:
        return "warning"
    return "pass" if target == scholarship.get("degree_level") else "fail"


def _check_subject(candidate: dict, scholarship: pd.Series) -> str:
    target = candidate.get("intended_subject")
    if not target:
        return "warning"
    return "pass" if target == scholarship.get("subject") else "fail"


def _check_country_eligibility(candidate: dict, scholarship: pd.Series) -> str:
    eligibility_text = str(scholarship.get("eligibility", "")).lower()
    if "international students eligible" in eligibility_text:
        return "pass"
    if "domestic students only" in eligibility_text:
        # If candidate's citizenship matches the scholarship's country, still fine.
        if candidate.get("citizenship_country") and candidate.get("citizenship_country") == scholarship.get("country"):
            return "pass"
        return "fail"
    return "warning"


def _check_academic(candidate: dict, scholarship: pd.Series, grade_mapping: pd.DataFrame) -> str:
    value = candidate.get("score_value")
    score_type = candidate.get("score_type")
    if value in (None, "") or not score_type:
        return "warning"
    try:
        value = float(value)
    except (TypeError, ValueError):
        return "warning"

    result = normalize_grade(value, score_type, grade_mapping, country=candidate.get("citizenship_country"))
    if not result.matched:
        return "warning"

    min_gpa_text = str(scholarship.get("minimum_gpa", "")).lower()
    if "no fixed minimum" in min_gpa_text:
        return "pass"
    # Require at least "Merit" band for a pass; below that is a fail; unclear stays warning.
    rank = band_rank(result.normalized_band)
    if rank == -1:
        return "warning"
    return "pass" if rank >= band_rank("Merit") else "fail"


def _check_english(candidate: dict, scholarship: pd.Series) -> str:
    ielts = candidate.get("ielts")
    toefl = candidate.get("toefl")
    requirement = str(scholarship.get("language_requirement", ""))
    if not requirement or "No standardized test required" in requirement:
        return "pass"
    if ielts in (None, "") and toefl in (None, ""):
        return "warning"
    try:
        if ielts not in (None, "") and float(ielts) >= 6.5:
            # Rough check against the lowest published IELTS threshold format ("IELTS X.X+")
            import re
            m = re.search(r"IELTS\s*([\d.]+)", requirement)
            if m and float(ielts) >= float(m.group(1)):
                return "pass"
            if m:
                return "fail"
        if toefl not in (None, ""):
            import re
            m = re.search(r"TOEFL\s*(\d+)", requirement)
            if m and float(toefl) >= float(m.group(1)):
                return "pass"
            if m:
                return "fail"
    except (TypeError, ValueError):
        return "warning"
    return "warning"


def _check_deadline(scholarship: pd.Series, as_of: Optional[datetime] = None) -> str:
    as_of = as_of or datetime.now()
    deadline = scholarship.get("deadline")
    if pd.isna(deadline):
        return "warning"
    try:
        deadline_dt = pd.to_datetime(deadline)
    except Exception:
        return "warning"
    return "fail" if deadline_dt < as_of else "pass"


def evaluate_match(candidate: dict, scholarship: pd.Series, grade_mapping: pd.DataFrame) -> MatchResult:
    checks = {
        CHECK_LABELS["degree"]: _check_degree(candidate, scholarship),
        CHECK_LABELS["subject"]: _check_subject(candidate, scholarship),
        CHECK_LABELS["country_eligibility"]: _check_country_eligibility(candidate, scholarship),
        CHECK_LABELS["academic"]: _check_academic(candidate, scholarship, grade_mapping),
        CHECK_LABELS["english"]: _check_english(candidate, scholarship),
        CHECK_LABELS["deadline"]: _check_deadline(scholarship),
    }

    if checks[CHECK_LABELS["deadline"]] == "fail":
        overall = "Deadline Passed"
    elif "fail" in checks.values():
        overall = "Not Currently Matching"
    elif "warning" in checks.values():
        overall = "Needs Verification"
    else:
        overall = "Potentially Eligible"

    return MatchResult(scholarship_id=scholarship.get("scholarship_id"), checks=checks, overall=overall)


def run_matching(candidate: dict, scholarships: pd.DataFrame, grade_mapping: pd.DataFrame) -> List[MatchResult]:
    return [evaluate_match(candidate, row, grade_mapping) for _, row in scholarships.iterrows()]
